# name:"dietician"

## Description
A dietician is a dietary assessment tool that consist of a structured interview in which participants are asked to recall all food and drink they have consumed in the previous 24/7 days etc. Summary: It relies on a trained interviewer to give proper dataset and interviewing questions to set in the mobile application, an accurate memory of intake, an ability to estimate portion size, and the interviews’ reliability to not misreport.Built AI Based smart food analyzer Application that allows user to keep track of their food and also recommend best dietary chart based on their vat, pitta, and kapha state. And also (Carbo/fat/protein etc...) (Ayurveda – Rasa etc.) Mobile application should generate monthly /weekly report of the user.

## Links
GitHub Repo link: https://github.com/narmadha-17/dietician-app
## Technology stack
    1. Java
    2. XML
    3. Android Studio
## Project Setup
To setup this project on your device, simply clone the GitHub repo to your android studio and you are ready to use this project.
## Usage and its Applications
To use this project on your android device, build an apk file(it will get stored in debug folder) and dowload it in your devices enabling all asked permissions.
AI Based smart food analyzer Application that allows user to keep track of their food and also recommend best dietary chart based on their vat, pitta, and kapha state. And also (Carbo/fat/protein etc...) (Ayurveda – Rasa etc.) Mobile application should generate monthly /weekly report of the user.
## Future Scope
To implement realtime database.