package com.example.dietician;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.Random;

public class navBar extends AppCompatActivity {
    ImageView date;
    ImageView dish;

    ImageButton bmi_button, calorie_button, tips_button;
    private DrawerLayout dl;
    private ActionBarDrawerToggle abdt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav_bar);

        date = findViewById(R.id.dates);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://pharmeasy.in/blog/health-benefits-of-dates/");
            }
        });

        dish=findViewById(R.id.rajma);
        dish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://timesofindia.indiatimes.com/life-style/health-fitness/weight-loss/weight-loss-the-best-timings-for-your-meals-to-lose-weight-effectively/photostory/69163968.cms");
            }
        });



        dl = (DrawerLayout) findViewById(R.id.drawer);
        abdt = new ActionBarDrawerToggle(this,dl,R.string.Open,R.string.Close);
        abdt.setDrawerIndicatorEnabled(true);
        dl.addDrawerListener(abdt);
        abdt.syncState();
        final String tips[] = {"Eat a healthy diet","Consume less salt and sugar","Reduce intake of harmful fats",
        "Avoid harmful use of alcohol","Don’t smoke","Check your blood pressure regularly","Get vaccinated",
                "Cover your mouth when coughing or sneezing","Prevent mosquito bites","Drink only safe water",
                "Talk to someone you trust if you're feeling down","Take antibiotics only as prescribed",
        "Clean your hands properly","Have regular check-ups"};
        Random random = new Random();


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        final NavigationView nav_view = (NavigationView)findViewById(R.id.nav_View);
        nav_view.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener()
        {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();



                if (id == R.id.item2) {
                    Intent intent=new Intent(navBar.this,action_plan.class);
                    startActivity(intent);
                   return true;
                }
                else if (id == R.id.item3) {
                    Intent intent =new Intent (navBar.this,mental_wellness.class);
                    startActivity(intent);
                    return true;
                }
                else if (id == R.id.item4) {
                    Intent intent=new Intent(navBar.this,diet_and_fitness.class);
                    startActivity(intent);
                    return true;
                }
                else if (id == R.id.item5) {
                    Intent intent=new Intent(navBar.this,goal_setting.class);
                    startActivity(intent);
                    return true;
                }
                else if (id == R.id.item6) {
                    Intent intent=new Intent(navBar.this,reminders.class);
                    startActivity(intent);
                    return true;
                }

                else if (id == R.id.item8) {
                    Intent intent=new Intent(navBar.this,freecredits.class);
                    startActivity(intent);
                    return true;
                }
                else if (id == R.id.item9) {
                    Intent intent=new Intent(navBar.this,settings.class);
                    startActivity(intent);
                    return true;
                }

                return true;
            }
        });

        bmi_button = findViewById(R.id.imageButton4);
        bmi_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),bmii.class);
                startActivity(intent);

            }
        });

        calorie_button = findViewById(R.id.imageButton3);
        calorie_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),calorie.class);
                startActivity(intent);
            }
        });


        View water_button = findViewById(R.id.imageButton1);
        water_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),alarm.class);
                startActivity(intent);
            }
        });
        
        
        tips_button = findViewById(R.id.imageButton2);
        tips_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index = random.nextInt(tips.length);
                Toast.makeText(getApplicationContext(),tips[index],Toast.LENGTH_SHORT).show();
            }
        });



    }

    private void gotoUrl(String s) {
        Uri uri=Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return abdt.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }
}